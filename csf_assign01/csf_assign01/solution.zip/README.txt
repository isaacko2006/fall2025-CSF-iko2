TODO: add information about contributions of team member(s)
Isaac Ko (iko2@jh.edu)
Gavin Simurdiak (gsimurd1@jh.edu)

Contributions:
Although we mostly worked together on this first milestone (and it was fairly brief as well), we definitely were more drawn
to different sections of the assignment. Isaac did the fixpoint_init, fixpoint_get_whole, and fixpoint_get_frac methods while
also constantly running the tests on the code to make sure it passed. Gavin took care of the fixpoint_is_negative as well as the 
fixpoint_negate methods while also being in charge of checking valgrind for the code and writing the README. 