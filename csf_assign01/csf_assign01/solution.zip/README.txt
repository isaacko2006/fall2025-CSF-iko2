TODO: add information about contributions of team member(s)
Isaac Ko (iko2@jh.edu)
Gavin Simurdiak (gsimurd1@jh.edu)

Contributions:
Although we mostly worked together on this first milestone (and it was fairly brief as well), we definitely were more drawn
to different sections of the assignment. Isaac did the fixpoint_init, fixpoint_get_whole, and fixpoint_get_frac methods while
also constantly running the tests on the code to make sure it passed. Gavin took care of the fixpoint_is_negative as well as the 
fixpoint_negate methods while also being in charge of checking valgrind for the code and writing the README. 

Milestone 2:
We worked together on the majority of this assignment (sitting side-by-side discussing code). Specifically, fixpoint_add and 
the helper methods, fixpoint_sub, and fixpoint_compare were written by Isaac. Gavin wrote fixpoint_mul, fixpoint_format_hex, 
and fixpoint_parse_hex. Isaac wrote the unit tests in the fixpoint_tests.c file. Both of us contributed to continual 
debugging of the code. 