TODO: names of team members
Isaac Ko 
-iko2@jh.edu
Gavin Simurdiak
-gsimurd1@jh.edu

TODO: contributions of each team member
Isaac: Completed the ellipse function and helped with the emboss function.

Gavin: Completed the emboss function with help from Isaac.