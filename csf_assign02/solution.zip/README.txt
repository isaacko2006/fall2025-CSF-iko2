TODO: names of team members
Isaac Ko 
-iko2@jh.edu
Gavin Simurdiak
-gsimurd1@jh.edu

TODO: contributions of each team member
Isaac: Completed complement, transpose, and ellipse functions as well as doing a lot of testing and improvement when tests failed

Gavin: Completed emboss function, all get helper functions (r,g,b,a), as well as the emboss_gray helper function, and wrote unit tests for the helper functions
