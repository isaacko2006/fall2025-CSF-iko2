TODO: names of team members
Isaac Ko 
-iko2@jh.edu
Gavin Simurdiak
-gsimurd1@jh.edu

TODO: contributions of each team member
Isaac: Completed complement function (and the helper functions).

Gavin: Completed the transpose function and also debugged all of the written code to check for memory errors or logical faults. 
