TODO: names of team members and their contributions to the project
Milestone 1:
Isaac Ko: Set up Github repository, downloaded and starter code, put in #include statements and a brief framework for main.cpp
Gavin Simurdiak: Adjusted Isaac's original main.cpp, added error checking for parameter arguments and file not opening, stores contents of file to variables and output to cout

TODO (for MS3): best cache report
